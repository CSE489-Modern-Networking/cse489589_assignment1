cd .. && rsync -ri ../* s:project
