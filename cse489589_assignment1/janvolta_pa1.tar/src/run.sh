 cd .. && make && cd src && ./copy.sh  
